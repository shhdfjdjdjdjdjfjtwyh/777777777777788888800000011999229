package com.bloody.unitconverter;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.view.animation.AnimationUtils;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import com.google.android.material.button.MaterialButton;

public class DeveloperActivity extends AppCompatActivity {

    private static final String TELEGRAM = "https://t.me/BLOODYNIGHTMODMENU";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_developer);

        View root = findViewById(R.id.devRoot);
        root.startAnimation(AnimationUtils.loadAnimation(this, android.R.anim.fade_in));

        ImageView back = findViewById(R.id.btnBack);
        back.setOnClickListener(v -> {
            finish();
            overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out);
        });

        TextView handle = findViewById(R.id.tvHandle);
        MaterialButton tgBtn = findViewById(R.id.btnTelegram);

        View.OnClickListener openTg = v -> {
            try {
                Intent i = new Intent(Intent.ACTION_VIEW, Uri.parse(TELEGRAM));
                startActivity(i);
            } catch (Exception ignored) {}
        };

        handle.setOnClickListener(openTg);
        tgBtn.setOnClickListener(openTg);
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out);
    }
}