package com.bloody.unitconverter;

public class ConverterEngine {

    static {
        System.loadLibrary("native-converter");
    }

    // Native method
    public static native double nativeConvert(int category, int fromUnit, int toUnit, double value);
    public static native String nativeVersion();

    // Wrapper
    public static double convert(int category, int fromUnit, int toUnit, double value) {
        try {
            return nativeConvert(category, fromUnit, toUnit, value);
        } catch (Throwable t) {
            return value;
        }
    }

    public static String engineVersion() {
        try {
            return nativeVersion();
        } catch (Throwable t) {
            return "Native Engine";
        }
    }

    // Unit data per category
    public static final String[][] UNITS = {
        // 0 Length
        {"Meter", "Kilometer", "Centimeter", "Millimeter", "Mile", "Yard", "Foot", "Inch"},
        // 1 Weight
        {"Kilogram", "Gram", "Milligram", "Ton", "Pound", "Ounce"},
        // 2 Temperature
        {"Celsius", "Fahrenheit", "Kelvin"},
        // 3 Area
        {"Sq Meter", "Sq Kilometer", "Sq Foot", "Acre", "Hectare"},
        // 4 Volume
        {"Liter", "Milliliter", "Gallon (US)", "Cubic Meter"},
        // 5 Speed
        {"km/h", "m/s", "mph", "Knot"},
        // 6 Time
        {"Second", "Minute", "Hour", "Day", "Week", "Month", "Year"},
        // 7 Data
        {"Byte", "KB", "MB", "GB", "TB", "PB"}
    };

    public static final String[] CATEGORIES = {
        "Length", "Weight", "Temperature", "Area",
        "Volume", "Speed", "Time", "Data"
    };

    public static String[] getUnits(int category) {
        if (category < 0 || category >= UNITS.length) return UNITS[0];
        return UNITS[category];
    }
}