#include <jni.h>
#include <string>
#include <cmath>
#include <android/log.h>

#define LOG_TAG "NativeConverter"
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO, LOG_TAG, __VA_ARGS__)

extern "C" {

// Base factors to SI unit (per category)
// length (meter), weight (kg), area (sq meter), volume (liter),
// speed (m/s), time (second), data (byte)

static double lengthFactor(int unit) {
    switch (unit) {
        case 0: return 1.0;              // Meter
        case 1: return 1000.0;           // Kilometer
        case 2: return 0.01;             // Centimeter
        case 3: return 0.001;            // Millimeter
        case 4: return 1609.344;         // Mile
        case 5: return 0.9144;           // Yard
        case 6: return 0.3048;           // Foot
        case 7: return 0.0254;           // Inch
    }
    return 1.0;
}

static double weightFactor(int unit) {
    switch (unit) {
        case 0: return 1.0;              // Kilogram
        case 1: return 0.001;            // Gram
        case 2: return 0.000001;         // Milligram
        case 3: return 1000.0;           // Ton (metric)
        case 4: return 0.45359237;       // Pound
        case 5: return 0.028349523125;   // Ounce
    }
    return 1.0;
}

static double areaFactor(int unit) {
    switch (unit) {
        case 0: return 1.0;              // Sq Meter
        case 1: return 1000000.0;        // Sq Kilometer
        case 2: return 0.09290304;       // Sq Foot
        case 3: return 4046.8564224;     // Acre
        case 4: return 10000.0;          // Hectare
    }
    return 1.0;
}

static double volumeFactor(int unit) {
    switch (unit) {
        case 0: return 1.0;              // Liter
        case 1: return 0.001;            // Milliliter
        case 2: return 3.785411784;      // US Gallon
        case 3: return 1000.0;           // Cubic Meter
    }
    return 1.0;
}

static double speedFactor(int unit) {
    switch (unit) {
        case 0: return 0.2777777778;     // km/h
        case 1: return 1.0;              // m/s
        case 2: return 0.44704;          // mph
        case 3: return 0.5144444444;     // knot
    }
    return 1.0;
}

static double timeFactor(int unit) {
    switch (unit) {
        case 0: return 1.0;              // Second
        case 1: return 60.0;             // Minute
        case 2: return 3600.0;           // Hour
        case 3: return 86400.0;          // Day
        case 4: return 604800.0;         // Week
        case 5: return 2629800.0;        // Month (avg)
        case 6: return 31557600.0;       // Year (365.25 days)
    }
    return 1.0;
}

static double dataFactor(int unit) {
    // Using binary (1024) scale
    switch (unit) {
        case 0: return 1.0;                                  // Byte
        case 1: return 1024.0;                               // KB
        case 2: return 1048576.0;                            // MB
        case 3: return 1073741824.0;                         // GB
        case 4: return 1099511627776.0;                      // TB
        case 5: return 1125899906842624.0;                   // PB
    }
    return 1.0;
}

static double getFactor(int category, int unit) {
    switch (category) {
        case 0: return lengthFactor(unit);
        case 1: return weightFactor(unit);
        case 3: return areaFactor(unit);
        case 4: return volumeFactor(unit);
        case 5: return speedFactor(unit);
        case 6: return timeFactor(unit);
        case 7: return dataFactor(unit);
    }
    return 1.0;
}

JNIEXPORT jdouble JNICALL
Java_com_bloody_unitconverter_ConverterEngine_nativeConvert(
        JNIEnv *env, jclass clazz,
        jint category, jint fromUnit, jint toUnit, jdouble value) {

    // Temperature has special formulas
    if (category == 2) {
        double celsius;
        switch (fromUnit) {
            case 0: celsius = value; break;                          // Celsius
            case 1: celsius = (value - 32.0) * 5.0 / 9.0; break;     // Fahrenheit
            case 2: celsius = value - 273.15; break;                 // Kelvin
            default: celsius = value;
        }
        switch (toUnit) {
            case 0: return celsius;                                   // Celsius
            case 1: return celsius * 9.0 / 5.0 + 32.0;                // Fahrenheit
            case 2: return celsius + 273.15;                          // Kelvin
            default: return celsius;
        }
    }

    double fromF = getFactor(category, fromUnit);
    double toF = getFactor(category, toUnit);
    if (toF == 0.0) return value;
    return (value * fromF) / toF;
}

JNIEXPORT jstring JNICALL
Java_com_bloody_unitconverter_ConverterEngine_nativeVersion(
        JNIEnv *env, jclass clazz) {
    std::string v = "Native Engine v1.0 (C++17)";
    return env->NewStringUTF(v.c_str());
}

} // extern "C"