package com.bloody.unitconverter;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import java.util.List;

public class HistoryAdapter extends RecyclerView.Adapter<HistoryAdapter.VH> {

    private final List<HistoryItem> data;

    public HistoryAdapter(List<HistoryItem> data) {
        this.data = data;
    }

    @NonNull
    @Override
    public VH onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_history, parent, false);
        return new VH(v);
    }

    @Override
    public void onBindViewHolder(@NonNull VH h, int position) {
        HistoryItem it = data.get(position);
        h.tvInput.setText(it.input);
        h.tvOutput.setText("= " + it.output);
    }

    @Override
    public int getItemCount() {
        return data.size();
    }

    static class VH extends RecyclerView.ViewHolder {
        TextView tvInput, tvOutput;
        VH(@NonNull View itemView) {
            super(itemView);
            tvInput = itemView.findViewById(R.id.tvHistInput);
            tvOutput = itemView.findViewById(R.id.tvHistOutput);
        }
    }
}