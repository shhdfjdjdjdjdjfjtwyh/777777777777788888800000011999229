package com.bloody.unitconverter;

import android.content.Context;
import android.graphics.Color;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.RecyclerView;
import java.util.List;

public class CategoryAdapter extends RecyclerView.Adapter<CategoryAdapter.VH> {

    public interface OnCategoryClick {
        void onClick(int position);
    }

    private final Context context;
    private final List<String> data;
    private final OnCategoryClick listener;
    private int selected = 0;

    public CategoryAdapter(Context c, List<String> data, OnCategoryClick l) {
        this.context = c;
        this.data = data;
        this.listener = l;
    }

    public void setSelected(int pos) {
        int old = selected;
        selected = pos;
        notifyItemChanged(old);
        notifyItemChanged(selected);
    }

    @NonNull
    @Override
    public VH onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(context).inflate(R.layout.item_category, parent, false);
        return new VH(v);
    }

    @Override
    public void onBindViewHolder(@NonNull VH h, int position) {
        h.tv.setText(data.get(position));
        if (position == selected) {
            h.itemView.setBackgroundResource(R.drawable.chip_bg_selected);
            h.tv.setTextColor(Color.WHITE);
        } else {
            h.itemView.setBackgroundResource(R.drawable.chip_bg);
            h.tv.setTextColor(ContextCompat.getColor(context, R.color.text_secondary));
        }
        h.itemView.setOnClickListener(v -> {
            int p = h.getAdapterPosition();
            if (p == RecyclerView.NO_POSITION) return;
            setSelected(p);
            listener.onClick(p);
        });
    }

    @Override
    public int getItemCount() {
        return data.size();
    }

    static class VH extends RecyclerView.ViewHolder {
        TextView tv;
        VH(@NonNull View itemView) {
            super(itemView);
            tv = itemView.findViewById(R.id.tvCategory);
        }
    }
}