package com.bloody.unitconverter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import java.util.List;

public class UnitAdapter extends ArrayAdapter<String> {
    private final LayoutInflater inflater;

    public UnitAdapter(@NonNull Context context, @NonNull List<String> objects) {
        super(context, R.layout.item_unit, objects);
        inflater = LayoutInflater.from(context);
    }

    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        return create(position, convertView, parent);
    }

    @Override
    public View getDropDownView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        return create(position, convertView, parent);
    }

    private View create(int position, View convertView, ViewGroup parent) {
        if (convertView == null) convertView = inflater.inflate(R.layout.item_unit, parent, false);
        TextView tv = convertView.findViewById(R.id.tvUnit);
        tv.setText(getItem(position));
        return convertView;
    }
}