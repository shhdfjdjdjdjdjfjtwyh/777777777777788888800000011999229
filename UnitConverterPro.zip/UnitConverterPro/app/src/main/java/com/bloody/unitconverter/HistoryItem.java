package com.bloody.unitconverter;

public class HistoryItem {
    public final String input;
    public final String output;
    public final long timestamp;

    public HistoryItem(String input, String output, long timestamp) {
        this.input = input;
        this.output = output;
        this.timestamp = timestamp;
    }
}