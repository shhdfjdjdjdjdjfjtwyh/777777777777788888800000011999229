package com.bloody.unitconverter;

import android.animation.ObjectAnimator;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.view.animation.AnimationUtils;
import android.view.animation.OvershootInterpolator;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.button.MaterialButton;

import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    private RecyclerView rvCategories, rvHistory;
    private CategoryAdapter categoryAdapter;
    private HistoryAdapter historyAdapter;
    private final List<HistoryItem> history = new ArrayList<>();
    private EditText etInput;
    private Spinner spinnerFrom, spinnerTo;
    private TextView tvResult, tvEngine;
    private ImageView btnSwap, btnDev;
    private MaterialButton btnConvert;

    private int currentCategory = 0;
    private final DecimalFormat df = new DecimalFormat("#.########");

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        rvCategories = findViewById(R.id.rvCategories);
        rvHistory = findViewById(R.id.rvHistory);
        etInput = findViewById(R.id.etInput);
        spinnerFrom = findViewById(R.id.spinnerFrom);
        spinnerTo = findViewById(R.id.spinnerTo);
        tvResult = findViewById(R.id.tvResult);
        tvEngine = findViewById(R.id.tvEngine);
        btnSwap = findViewById(R.id.btnSwap);
        btnDev = findViewById(R.id.btnDev);
        btnConvert = findViewById(R.id.btnConvert);

        tvEngine.setText(ConverterEngine.engineVersion());

        // Categories
        rvCategories.setLayoutManager(
                new LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false));
        categoryAdapter = new CategoryAdapter(this,
                Arrays.asList(ConverterEngine.CATEGORIES),
                this::onCategorySelected);
        rvCategories.setAdapter(categoryAdapter);

        // History
        rvHistory.setLayoutManager(new LinearLayoutManager(this));
        historyAdapter = new HistoryAdapter(history);
        rvHistory.setAdapter(historyAdapter);

        // Entry animation
        View root = findViewById(R.id.rootLayout);
        root.startAnimation(AnimationUtils.loadAnimation(this, android.R.anim.fade_in));

        loadUnits(0);

        btnConvert.setOnClickListener(v -> doConvert());
        btnSwap.setOnClickListener(v -> swapUnits());
        btnDev.setOnClickListener(v -> {
            startActivity(new Intent(this, DeveloperActivity.class));
            overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out);
        });
    }

    private void onCategorySelected(int pos) {
        currentCategory = pos;
        loadUnits(pos);
        // subtle slide for result
        tvResult.setText("0");
        tvResult.startAnimation(AnimationUtils.loadAnimation(this, android.R.anim.fade_in));
    }

    private void loadUnits(int category) {
        String[] units = ConverterEngine.getUnits(category);
        List<String> list = Arrays.asList(units);
        UnitAdapter adapter = new UnitAdapter(this, list);
        spinnerFrom.setAdapter(adapter);
        UnitAdapter adapter2 = new UnitAdapter(this, new ArrayList<>(list));
        spinnerTo.setAdapter(adapter2);

        if (units.length > 1) {
            spinnerFrom.setSelection(0);
            spinnerTo.setSelection(1);
        } else {
            spinnerFrom.setSelection(0);
            spinnerTo.setSelection(0);
        }
    }

    private void swapUnits() {
        int from = spinnerFrom.getSelectedItemPosition();
        int to = spinnerTo.getSelectedItemPosition();
        spinnerFrom.setSelection(to);
        spinnerTo.setSelection(from);

        ObjectAnimator rot = ObjectAnimator.ofFloat(btnSwap, "rotation", 0f, 180f);
        rot.setDuration(300);
        rot.setInterpolator(new OvershootInterpolator());
        rot.start();
        btnSwap.setRotation(0f);

        if (!TextUtils.isEmpty(etInput.getText().toString())) doConvert();
    }

    private void doConvert() {
        String s = etInput.getText().toString().trim();
        if (s.isEmpty()) {
            shake(etInput);
            Toast.makeText(this, "Enter a value", Toast.LENGTH_SHORT).show();
            return;
        }

        double value;
        try {
            value = Double.parseDouble(s);
        } catch (NumberFormatException e) {
            shake(etInput);
            Toast.makeText(this, "Invalid number", Toast.LENGTH_SHORT).show();
            return;
        }

        int from = spinnerFrom.getSelectedItemPosition();
        int to = spinnerTo.getSelectedItemPosition();

        if (from < 0 || to < 0) return;

        double result;
        try {
            result = ConverterEngine.convert(currentCategory, from, to, value);
        } catch (Throwable t) {
            Toast.makeText(this, "Conversion error", Toast.LENGTH_SHORT).show();
            return;
        }

        String resultStr = df.format(result);
        tvResult.setText(resultStr);

        // Pop animation
        tvResult.setScaleX(0.85f);
        tvResult.setScaleY(0.85f);
        tvResult.animate().scaleX(1f).scaleY(1f)
                .setDuration(280)
                .setInterpolator(new OvershootInterpolator())
                .start();

        String fromUnit = String.valueOf(spinnerFrom.getSelectedItem());
        String toUnit = String.valueOf(spinnerTo.getSelectedItem());
        String inputLine = s + " " + fromUnit + " → " + toUnit;

        history.add(0, new HistoryItem(inputLine, resultStr + " " + toUnit,
                System.currentTimeMillis()));
        while (history.size() > 10) history.remove(history.size() - 1);
        historyAdapter.notifyDataSetChanged();
    }

    private void shake(View v) {
        ObjectAnimator.ofFloat(v, "translationX",
                0, 12, -12, 8, -8, 4, -4, 0)
                .setDuration(400).start();
    }
}